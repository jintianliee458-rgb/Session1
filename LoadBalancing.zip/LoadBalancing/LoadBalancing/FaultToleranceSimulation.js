import http from "node:http";
import { writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import LoadBalancer from "./LoadBalancer.js";
import Utils from "./Util.js";

const workload = {
    requests: 50,
    intervalMs: 200,
    failureAtMs: 2000,
    restoreAtMs: 6000,
    requestDeadlineMs: 3000
};

const config = {
    LoadBalancingAlgorithm: Utils.AlgorithmStr[1],
    NoServers: 2,
    Replicas: 3,
    MaxNoSessionsPerServer: 50,
    MinNoSessionsPerServer: 50,
    MaxProcessingTime: 500,
    MinProcessingTime: 500,
    NoDatastores: 2,
    MaxDatastoreSpace: 1000000,
    MinDatastoreSpace: 1000000,
    MaxSizeRequestPayload: 1,
    MinSizeRequestPayload: 1,
    Port: 0,
    HealthCheckInterval: 1000,
    HealthCheckTimeout: 500,
    RequestTimeout: 2000
};

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Every request has a fixed deadline, including connection and response time.
function sendRequest(url) {
    return new Promise(resolve => {
        const startedAt = Date.now();
        let finished = false;
        let deadline;
        const finish = (kind, backendId = null) => {
            if (finished) return;
            finished = true;
            clearTimeout(deadline);
            const completedAt = Date.now();
            resolve({ kind, backendId, completedAt, latencyMs: completedAt - startedAt });
        };

        const req = http.get(url, res => {
            let body = "";
            res.setEncoding("utf8");
            res.on("data", chunk => { body += chunk; });
            res.on("end", () => {
                const accepted = res.statusCode >= 200 && res.statusCode < 300
                    && body.includes("ACCESS GRANTED");
                finish(accepted ? "success" : "failedResponse", res.headers["x-backend-id"]);
            });
            res.on("aborted", () => finish("networkFailure"));
            res.on("error", () => finish("networkFailure"));
        });
        req.on("error", () => finish("networkFailure"));
        deadline = setTimeout(() => {
            finish("timeout");
            req.destroy();
        }, workload.requestDeadlineMs);
    });
}

async function runTest(enabled) {
    const balancer = new LoadBalancer({ ...config, FaultTolerance: enabled });
    const timers = [];
    try {
        await balancer.ready;
        const url = `http://127.0.0.1:${balancer.httpserver.address().port}/hello`;
        const startedAt = Date.now();
        let restoredAt = null;
        timers.push(setTimeout(() => {
            balancer.serverFactory.setAvailable("S0", false);
            console.log("S0 failed");
        }, workload.failureAtMs));
        timers.push(setTimeout(() => {
            balancer.serverFactory.setAvailable("S0", true);
            restoredAt = Date.now();
            console.log("S0 restored");
        }, workload.restoreAtMs));

        const requests = [];
        for (let i = 0; i < workload.requests; i++) {
            await sleep(Math.max(0, startedAt + i * workload.intervalMs - Date.now()));
            requests.push(sendRequest(url));
        }
        const responses = await Promise.all(requests);
        const count = kind => responses.filter(response => response.kind === kind).length;
        const firstRecovered = responses.find(response => response.kind === "success"
            && response.backendId === "S0" && restoredAt !== null
            && response.completedAt >= restoredAt);

        return {
            faultTolerance: enabled ? "On" : "Off",
            total: responses.length,
            successful: count("success"),
            successRate: `${(count("success") / responses.length * 100).toFixed(2)}%`,
            failedResponses: count("failedResponse"),
            networkFailures: count("networkFailure"),
            timeouts: count("timeout"),
            meanLatencyMs: Number((responses.reduce((sum, r) => sum + r.latencyMs, 0)
                / responses.length).toFixed(2)),
            recoveryTimeMs: balancer.serverFactory.getServers().get("S0").recoveryTimeMs ?? null,
            firstSuccessAfterRestoreMs: firstRecovered ? firstRecovered.completedAt - restoredAt : null
        };
    } finally {
        timers.forEach(clearTimeout);
        await balancer.close();
    }
}

export async function main() {
    const results = [];
    for (const enabled of [false, true]) {
        console.log(`\nTesting fault tolerance ${enabled ? "On" : "Off"}`);
        results.push(await runTest(enabled));
    }
    console.table(results);
    await writeFile(new URL("./B1-results.json", import.meta.url),
        JSON.stringify({ config, workload, results }, null, 2) + "\n");
    console.log("Saved B1-results.json");
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
    main().catch(error => {
        console.error(error);
        process.exitCode = 1;
    });
}
