# Jintian Li worked with my teammate - Hongyi Long
# System Design: Load Balancing Testbed
This is an implementation of a testbed for validating and optimizing load balancing in a system architectural design.

## Configuration

Configuration is currently defined in `MainTerminal.js`. Start the program with:

```sh
node MainTerminal.js
```

The console displays the current configuration and lets you change its values before choosing `Y` to start the load balancer. Changes apply only to the current run; they are not saved when the program exits.

After you choose `Y`, the program prints a startup message for the load balancer, followed by one entry for each backend server it creates. Backend ports and server limits are selected at runtime, so their values can differ between runs. The output is similar to:

```text
LoadBalancer is running on http://127.0.0.1:8080
Server {
  name: 'http://127.0.0.1:<port>',
  id: 'S0',
  maxSessions: <value>,
  processTime: <value>,
  sessions: []
}
```

It then periodically prints status objects for the servers (`id`, `Server`, `MaxSessions`, `processTime`, `Active`, and `limitReached`) and datastores (`id`, `Name`, `MaxStorage`, and `StorageLeft`). These values change as requests are handled. One timer prints the full status every four seconds. The program keeps running to serve requests; stop it with `Ctrl+C`.

The configuration has the following shape:

 ```yaml
 config = {
        LoadBalancingAlgorithm: <value>,
        NoServers: <value>,
        Replicas: <value>,
        MaxNoSessionsPerServer: <value>,
        MinNoSessionsPerServer: <value>,
        MaxProcessingTime: <value>, //seconds
        MinProcessingTime: <value>, //seconds
        NoDatastores: <value>,
        MaxDatastoreSpace: <value>, //GB
        MinDatastoreSpace: <value>, //MB
        MaxSizeRequestPayload: <value>, //MB
        MinSizeRequestPayload: <value>, //MB
    }
```

The testbed evaluates three load-balancing algorithms. These are `Round Robin`, `Least Connections` and `Consistent Hashing`. Given an configuration instance, the aim is to verify the limits of the system in its ability to be highly-available, resilient and to withstand a denial of service attack. 

The effectiveness of a configuration is measured by the frequency of server denial of access either due to lack of servers to handle new sessions or not enough space in the datastore to handle user request payload.


#Task A
## 1: 
https://lucid.app/lucidchart/cbdb825f-446c-4f20-a381-19d99f911df8/edit?viewport_loc=-63%2C23%2C1599%2C1023%2C0_0&invitationId=inv_457aa295-2b6f-43a8-882c-0229d978c693

## 4: node RequestSimulation.js 
=== FINAL SUMMARY ===
┌─────────┬──────────┬───────┬─────────┬─────────┬─────────────┬─────────────┐
│ (index) │ interval │ total │ success │ failure │ successRate │ failureRate │
├─────────┼──────────┼───────┼─────────┼─────────┼─────────────┼─────────────┤
│    0    │   500    │  50   │   39    │   11    │  '78.00%'   │  '22.00%'   │
│    1    │   450    │  50   │   34    │   16    │  '68.00%'   │  '32.00%'   │
│    2    │   400    │  50   │   29    │   21    │  '58.00%'   │  '42.00%'   │
│    3    │   350    │  50   │   27    │   23    │  '54.00%'   │  '46.00%'   │
│    4    │   300    │  50   │   21    │   29    │  '42.00%'   │  '58.00%'   │
│    5    │   250    │  50   │   20    │   30    │  '40.00%'   │  '60.00%'   │
│    6    │   200    │  50   │   13    │   37    │  '26.00%'   │  '74.00%'   │
│    7    │   150    │  50   │   11    │   39    │  '22.00%'   │  '78.00%'   │
│    8    │   100    │  50   │   10    │   40    │  '20.00%'   │  '80.00%'   │
│    9    │    50    │  50   │    2    │   48    │   '4.00%'   │  '96.00%'   │
│   10    │    30    │  50   │    3    │   47    │   '6.00%'   │  '94.00%'   │
│   11    │    20    │  50   │    0    │   50    │   '0.00%'   │  '100.00%'  │
│   12    │    15    │  50   │    4    │   46    │   '8.00%'   │  '92.00%'   │
│   13    │    10    │  50   │    0    │   50    │   '0.00%'   │  '100.00%'  │
│   14    │    5     │  50   │    0    │   50    │   '0.00%'   │  '100.00%'  │
│   15    │    1     │  50   │    0    │   50    │   '0.00%'   │  '100.00%'  │
└─────────┴──────────┴───────┴─────────┴─────────┴─────────────┴─────────────┘

## 5: Results

With 50 requests per interval, success fell from 78% at 500 ms to 0% at 1 ms. Faster requests caused more failures. Earlier tests may affect later results because sessions and storage were not reset.

## 6: More configurations

We plan to test more servers, more sessions per server, faster processing, Least Connections, and more storage separately. We will use the same workload and restart for each configuration. These tests are not finished yet.

## 7: Larger workloads

We plan to repeat Tasks A(1)–A(6) with 500, 5000 and 1000000 requests. These tests are not finished yet. The million-request test needs memory improvements; sending at 500 ms takes about 5.8 days per test.

# Task B

## 1: Fault tolerance

We added health checks every second. The load balancer skips unavailable servers and adds them back after a successful check. Connection errors and timeouts return a failed response instead of stopping the program. In `MainTerminal.js`, `FaultTolerance: true` enables this feature.

```mermaid
flowchart LR
    Client --> LB[Load balancer]
    LB --> S0[Server S0]
    LB --> S1[Server S1]
    LB -. Health checks .-> S0
    LB -. Health checks .-> S1
    S0 --> DB[Datastores]
    S1 --> DB
```

Run the comparison on its own:

```sh
node FaultToleranceSimulation.js
```

The script starts a fresh testbed for each mode and sends 50 requests at 200 ms intervals. S0 becomes unavailable at 2 seconds and returns at 6 seconds. It uses fixed settings to focus on server failure. Results are saved in `B1-results.json`.

| Fault tolerance | Successful | Failed responses | Success rate | Lost or timed out |
|---|---:|---:|---:|---:|
| Off | 40 | 10 | 80.00% | 0 |
| On | 49 | 1 | 98.00% | 0 |

In this run, S0 was detected as healthy 3 ms after restoration and accepted its first new request after 402 ms. These times vary with the check and request timing. Health checks add traffic, and requests can still fail before a fault is detected. The demo simulates service unavailability; it does not kill the process or replay existing sessions. Success means session acceptance.
