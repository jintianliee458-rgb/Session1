
import http from "node:http";

const URL = "http://127.0.0.1:8080/hello";

// Number of requests in each test
const TOTAL_REQUESTS = 50;

// Request intervals in milliseconds
const INTERVALS = [
    500, 450, 400, 350, 300,
    250, 200, 150, 100, 50,
    30, 20, 15, 10, 5, 1
];
 
// Wait for a specified time
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Send one request and return its result
function sendRequest() {
    return new Promise((resolve) => {
        const req = http.get(URL, (res) => {
            let data = "";

            res.on("data", (chunk) => {
                data += chunk;
            });

            res.on("end", () => {
                if (data.includes("ACCESS GRANTED")) {
                    resolve("success");
                } else if (data.includes("No server available")) {
                    resolve("server_failure");
                } else if (data.includes("not available in datastore")) {
                    resolve("database_failure");
                } else {
                    resolve("other_failure");
                }
            });

            res.on("error", () => resolve("network_failure"));
        });

        req.on("error", () => resolve("network_failure"));

        req.setTimeout(10000, () => {
            req.destroy();
        });
    });
}

// Test one request interval
async function runTest(interval) {
    console.log(`\nTesting interval: ${interval} ms`);

    const requests = [];
    const startTime = Date.now();

    for (let i = 0; i < TOTAL_REQUESTS; i++) {
        requests.push(sendRequest());

        // Do not wait for the previous request to finish
        if (i < TOTAL_REQUESTS - 1) {
            await sleep(interval);
        }
    }

    // Wait until every request has a result
    const results = await Promise.all(requests);

    const success = results.filter(r => r === "success").length;
    const serverFailure = results.filter(r => r === "server_failure").length;
    const databaseFailure = results.filter(r => r === "database_failure").length;
    const otherFailure = results.filter(r => r === "other_failure").length;
    const networkFailure = results.filter(r => r === "network_failure").length;

    const failure = TOTAL_REQUESTS - success;
    const successRate = (success / TOTAL_REQUESTS) * 100;
    const failureRate = (failure / TOTAL_REQUESTS) * 100;

    console.log("Total Requests:", TOTAL_REQUESTS);
    console.log("Successful:", success);
    console.log("Failed:", failure);
    console.log("Server Failures:", serverFailure);
    console.log("Database Failures:", databaseFailure);
    console.log("Other Failures:", otherFailure);
    console.log("Network Failures:", networkFailure);
    console.log("Success Rate:", successRate.toFixed(2) + "%");
    console.log("Failure Rate:", failureRate.toFixed(2) + "%");
    console.log("Test Duration:", Date.now() - startTime, "ms");

    return {
        interval,
        total: TOTAL_REQUESTS,
        success,
        failure,
        successRate: successRate.toFixed(2) + "%",
        failureRate: failureRate.toFixed(2) + "%"
    };
}

// Run all interval tests
async function main() {
    console.log("Starting Load Balancing Simulation...");

    const summary = [];

    for (const interval of INTERVALS) {
        const result = await runTest(interval);
        summary.push(result);
    }

    console.log("\n=== FINAL SUMMARY ===");
    console.table(summary);
}

main().catch(console.error);
