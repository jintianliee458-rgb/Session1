import * as http from "http"
import findFreePorts from "find-free-ports"
import Server from "./Server.js"
import DatabaseFactory from "./DatabaseFactory.js"
import Utils from "./Util.js"

const host = '127.0.0.1'

export default class ServerFactory {

    constructor() {
        this.servers = new Map()
        this.httpServers = new Map()
        this.statusTimer = undefined
    }

    getServers() {
        return this.servers
    }
    getServerName(index){
        return this.servers.get(`${index}`).name
    }

    getServerWithMinConnectionsIndex(){
        let iterator1 = this.servers.keys();
        let minkey = iterator1.next().value
        let minsessions = this.servers.get(minkey).getNoSessions()

        for (let [key, server] of this.servers) {
            if(server.getNoSessions() < minsessions){
                minkey = key
                minsessions = server.getNoSessions() 
            }
        }
        return minkey
    }

    async createServers(configuration_) {
        const configuration = configuration_
        await DatabaseFactory.createDatabases(configuration)

        let freeports = await findFreePorts(configuration.NoServers);

        for (let i = 0; i < freeports.length; i++) {
            let port = freeports[i]

            let maxSessions = Utils.getRandomInt(configuration.MinNoSessionsPerServer, configuration.MaxNoSessionsPerServer)
            let processTime = Utils.getRandomInt(configuration.MinProcessingTime, configuration.MaxProcessingTime) 

            let server = new Server(`S${i}`,`http://${host}:${port}`, maxSessions, processTime)
            server.available = true
            server.healthy = true
            server.restoredAt = null
            server.recoveryTimeMs = null
            this.servers.set(`S${i}`, server)

            let httpserver = http.createServer(
                async function (req, res) {
                    res.setHeader("Content-Type", "application/json");

                    // Health checks must not create sessions or use datastore space.
                    if (req.url === "/health") {
                        res.writeHead(server.available ? 200 : 503)
                        res.end(server.available ? "Healthy" : "No server available")
                        return
                    }
                    if (!server.available) {
                        res.writeHead(503)
                        res.end("Session ACCESS DENIED - No server available")
                        return
                    }

                    switch (req.url) {
                        case "/":
                            res.writeHead(200);
                            res.end(`Server ${i} is running on http://${host}:${port}`);
                            break
                        default:
                            res.writeHead(200);
                           
                            let requestPayloadRange = Utils.getRandomInt(configuration.MinSizeRequestPayload, configuration.MaxSizeRequestPayload) //random between 1MB and 100MB
                            let saved = await  DatabaseFactory.savePayloadToDatastore(requestPayloadRange)
                            if(saved){
                                let ip = req.connection.remoteAddress
                                let success = await server.addSession(ip)
                                if (success) {
                                    res.end(`Session ACCESS GRANTED on http://${host}:${port}`);
                                }
                                else {
                                    res.end(`Session ACCESS DENIED on http://${host}:${port} - No server available`);
                                }
                            }
                            else{
                                res.end(`Session ACCESS DENIED on http://${host}:${port} - request space of ${requestPayloadRange}MB is not available in datastore`);
                            }
                            
                            break
                    }

                }
            );
            this.httpServers.set(server.id, httpserver)
            try {
                await new Promise((resolve, reject) => {
                    httpserver.once('error', reject)
                    httpserver.listen(port, host, () => {
                        httpserver.removeListener('error', reject)
                        console.log(server)
                        resolve()
                    })
                })
            }
            catch (error) {
                await this.close()
                throw error
            }
        }

        // Show the status once per interval, rather than once per server.
        this.statusTimer = setInterval(() => {
            this.showServersStatus()
            DatabaseFactory.showDatabasesStatus()
        }, 4000)
    }

    setAvailable(id, available) {
        let server = this.servers.get(id)
        if (!server) {
            throw new Error(`Unknown server: ${id}`)
        }
        if (server.available === available) {
            return
        }
        server.available = available
        server.recoveryTimeMs = null
        server.restoredAt = available ? Date.now() : null
        console.log(`${id} ${available ? 'restored' : 'unavailable'}`)
    }

    async checkHealth(timeoutMs = 500) {
        await Promise.all([...this.servers.values()].map(server => {
            return new Promise(resolve => {
                let finished = false
                let timer
                const finish = healthy => {
                    if (finished) return
                    finished = true
                    clearTimeout(timer)
                    let wasHealthy = server.healthy
                    server.healthy = healthy
                    if (wasHealthy && !healthy) {
                        console.log(`${server.id} failed its health check`)
                    }
                    if (!wasHealthy && healthy) {
                        if (server.restoredAt !== null) {
                            server.recoveryTimeMs = Date.now() - server.restoredAt
                            console.log(`${server.id} recovery detected after ${server.recoveryTimeMs} ms`)
                        }
                        else {
                            console.log(`${server.id} passed its health check again`)
                        }
                    }
                    resolve()
                }

                const request = http.get(`${server.name}/health`, response => {
                    response.resume()
                    response.on('end', () => finish(response.statusCode === 200))
                    response.on('error', () => finish(false))
                    response.on('aborted', () => finish(false))
                })
                request.on('error', () => finish(false))
                timer = setTimeout(() => {
                    finish(false)
                    request.destroy()
                }, timeoutMs)
            })
        }))
    }

    async close() {
        clearInterval(this.statusTimer)
        for (let server of this.servers.values()) {
            server.close()
        }
        await Promise.all([...this.httpServers.values()].map(httpserver => {
            return new Promise(resolve => {
                httpserver.close(resolve)
                httpserver.closeAllConnections?.()
            })
        }))
        this.httpServers.clear()
    }

    showServersStatus() {
        function review(value, key, map) {
            let serverstatus = value.getStatus()
            console.log(serverstatus)
        }
        this.servers.forEach(review);
    }
}

