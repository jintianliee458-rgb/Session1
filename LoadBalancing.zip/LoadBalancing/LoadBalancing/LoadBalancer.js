import * as http from "http"
import crypto from "crypto"

import ServerFactory from "./ServerFactory.js"
import Utils from "./Util.js"

const host = '127.0.0.1'

export default class LoadBalancer {
    constructor(configuration) {
        this.configuration = configuration
        this.faultTolerance = configuration.FaultTolerance !== false
        this.serverFactory = new ServerFactory()
        this.checkingHealth = false

        switch (Utils.getAlgorithm(configuration.LoadBalancingAlgorithm)) {
            case Utils.Algorithm.RoundRobin:
                this.algorithm = new RoundRobin()
                break
            case Utils.Algorithm.LeastConnections:
                this.algorithm = new LeastConnections()
                break
            case Utils.Algorithm.ConsistentHashing:
                this.algorithm = new ConsistentHashing(configuration.NoServers, configuration.Replicas)
                break
            default:
                throw new Error('Unknown load-balancing algorithm')
        }

        this.httpserver = http.createServer((req, res) => this.handleRequest(req, res))
        this.ready = this.start()
    }

    async start() {
        try {
            await this.serverFactory.createServers(this.configuration)
            await new Promise((resolve, reject) => {
                this.httpserver.once('error', reject)
                this.httpserver.listen(this.configuration.Port ?? 8080, host, () => {
                    this.httpserver.removeListener('error', reject)
                    resolve()
                })
            })
            console.log(`LoadBalancer is running on http://${host}:${this.httpserver.address().port}`)

            if (this.faultTolerance) {
                this.healthTimer = setInterval(async () => {
                    if (this.checkingHealth) return
                    this.checkingHealth = true
                    try {
                        await this.serverFactory.checkHealth(this.configuration.HealthCheckTimeout ?? 500)
                    } catch (error) {
                        console.error('Health check failed:', error.message)
                    } finally {
                        this.checkingHealth = false
                    }
                }, this.configuration.HealthCheckInterval ?? 1000)
            }
        } catch (error) {
            await this.close()
            throw error
        }
    }

    handleRequest(req, res) {
        res.setHeader('Content-Type', 'text/plain')
        if (req.url === '/') {
            res.end('LoadBalancer is running. Send a session request to /hello.')
            return
        }

        // The baseline keeps routing to every server, including failed ones.
        const candidates = new Map([...this.serverFactory.getServers()].filter(
            ([, server]) => !this.faultTolerance || server.healthy
        ))
        const serverId = this.algorithm.getNext(req.url, candidates)
        if (serverId === undefined) {
            res.writeHead(503)
            res.end('Session ACCESS DENIED - No server available')
            return
        }

        const server = candidates.get(serverId)
        res.setHeader('X-Backend-Id', serverId)
        let finished = false
        let deadline
        const finish = (status, message) => {
            if (finished) return
            finished = true
            clearTimeout(deadline)
            if (!res.destroyed && !res.writableEnded) {
                res.writeHead(status)
                res.end(message)
            }
        }
        const fail = (status) => {
            if (this.faultTolerance) server.healthy = false
            finish(status, 'Session ACCESS DENIED - No server available')
        }

        const upstream = http.get(`${server.name}/start`, response => {
            let data = ''
            response.on('data', chunk => { data += chunk })
            response.on('end', () => {
                if (response.statusCode >= 500 && this.faultTolerance) server.healthy = false
                finish(response.statusCode, data)
            })
            response.on('error', () => fail(502))
            response.on('aborted', () => fail(502))
        })
        upstream.on('error', () => fail(502))
        deadline = setTimeout(() => {
            fail(504)
            upstream.destroy()
        }, this.configuration.RequestTimeout ?? 2000)
        res.on('close', () => {
            if (!finished) {
                finished = true
                clearTimeout(deadline)
                upstream.destroy()
            }
        })
    }

    async close() {
        clearInterval(this.healthTimer)
        await new Promise(resolve => {
            this.httpserver.close(() => resolve())
            this.httpserver.closeAllConnections?.()
        })
        await this.serverFactory.close()
    }
}

class RoundRobin {
    constructor() {
        this.next = -1
    }

    getNext(requestId, servers) {
        if (servers.size === 0) return undefined
        const ids = [...servers.keys()]
        this.next = (this.next + 1) % ids.length
        return ids[this.next]
    }
}

class LeastConnections {
    getNext(requestId, servers) {
        let selected
        let minimum = Infinity
        for (const [id, server] of servers) {
            if (server.getNoSessions() < minimum) {
                selected = id
                minimum = server.getNoSessions()
            }
        }
        return selected
    }
}

class ConsistentHashing {
    constructor(noServers, replicas) {
        this.ring = []
        for (let i = 0; i < replicas; i++) {
            for (let j = 0; j < noServers; j++) {
                this.ring.push({
                    id: `S${j}`,
                    hash: crypto.createHash('md5').update(`__S${j}${i}`).digest('hex')
                })
            }
        }
        this.ring.sort((a, b) => a.hash.localeCompare(b.hash))
    }

    getNext(requestId, servers) {
        const hash = crypto.createHash('md5').update(requestId).digest('hex')
        let start = this.ring.findIndex(node => node.hash >= hash)
        if (start === -1) start = 0
        // Walk around the ring until a healthy server is found.
        for (let i = 0; i < this.ring.length; i++) {
            const node = this.ring[(start + i) % this.ring.length]
            if (servers.has(node.id)) return node.id
        }
        return undefined
    }
}
